"use server"

import { CreateProgramParams } from "@/types";
import { handleError } from "../utils";
import { connectToDatabase } from "../database";
import Program from "../database/models/program.model";
import University from "../database/models/university.model";

const populateProgram = async (query:any) => {
    return query
    .populate({path: 'university', model: University, select: '_id name'})
}

export const createProgram = async({
    program
}: CreateProgramParams) => {
    try { 
        await connectToDatabase();

        const newProgram = await Program.create({ ...program, university: program.universityId });
        return JSON.parse(JSON.stringify(newProgram));
    }
    catch (error) {
        handleError(error)
    }
}

export const getProgramById = async (programId: string) => {
    try {
        await connectToDatabase();
        
        const program = await populateProgram(Program.findById(programId));

        if (!program) {
            throw new Error("No program found with the given id");
        }
        return JSON.parse(JSON.stringify(program))
    } catch (error) {
        handleError(error)
    }
}

export const getAllPrograms = async ({query, limit = 8, page, university: GetAllProgramsParams}) => {
    try {
        await connectToDatabase();

        const conditions = {};
        
        const programsQuery = Program.find(conditions).skip(0).limit(limit);

        const programs = await populateProgram(programsQuery)
        const programsCount = await Program.countDocuments(conditions);

        return {
            data: JSON.parse(JSON.stringify(programs)),
            totalPages: Math.ceil(programsCount / limit),
        }
    } catch (error) {
        handleError(error)
    }
}