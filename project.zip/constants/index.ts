export const headerLinks = [
  {
    label: 'Home',
    route: '/',
  },
  {
    label: 'Add Program',
    route: '/programs/create',
  },
  {
    label: 'My Profile',
    route: '/profile',
  },
]

export const programDefaultValues = {
  universityId: '',
  place: '',
  programName: '',
  degreeType: '',
  faculty: '',
  programDescription: '',
  courseRequirements: '',
  admissionRequirements: '',
  tuitionFeesDomestic: '',
  duration: '',
  deliveryMode: '',
  'Co-op/Internship': '',
  imageUrl:'',
}